from django.contrib import admin
from django import forms
from RRHH.models import Departamento, Empleado, Puesto, Sucursal,Nomina,Percepciones,Salida_Entrada

admin.site.register(Sucursal)
admin.site.register(Departamento)
admin.site.register(Puesto)
admin.site.register(Empleado)
admin.site.register(Nomina)
admin.site.register(Percepciones)
admin.site.register(Salida_Entrada

)



