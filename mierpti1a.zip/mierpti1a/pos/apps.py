from django.apps import AppConfig


class PuntoDeVentaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pos'
